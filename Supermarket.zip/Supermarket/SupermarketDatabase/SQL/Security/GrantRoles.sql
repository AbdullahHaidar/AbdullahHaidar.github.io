--Use SuperMarket
exec GrantCashierRole 'Csh01'
exec GrantCashierRole 'Csh02'
exec GrantStockManagerRole 'Stk01'





