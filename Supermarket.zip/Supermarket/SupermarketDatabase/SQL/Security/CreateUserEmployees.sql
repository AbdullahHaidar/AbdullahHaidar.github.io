/*drop user E102
drop login E102
*/
exec CreateUserEmployee 'Csh01','111'
exec CreateUserEmployee 'Csh02','111'
exec CreateUserEmployee 'Stk01','111'
