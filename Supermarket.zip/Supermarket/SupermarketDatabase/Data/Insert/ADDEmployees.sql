
exec AddEmployee  'Csh01',
				'Abdullah' ,
				'Haidar',
				'5-4-1998',
				'Lebanon,Beirut',
				'67/563572',
				'MALE',
				1500,
				'$',
				'Cashier'


exec AddEmployee 'Csh02',
				'Amira' ,
				'Baltajy',
				'7-3-1998',
				'Lebanon,Beirut',
				'67/594772',
				'FEMALE',
				1500,
				'$',
				'Cashier'

exec AddEmployee 'Stk01',
				'Jad' ,
				'Mrad',
				'11-9-1998',
				'Lebanon,Beirut',
				'67/438072',
				'MALE',
				2000,
				'$',
				'StockManager'
exec AddEmployee 'sa',
				'Abdullah' ,
				'Haidar',
				'3-14-1992',
				'Lebanon,Beirut',
				'67/170995',
				'MALE',
				9000,
				'$',
				'Administrater'
exec AddEmployee  'dbo',
				'Supermarket' ,
				'Manager',
				'5-4-1968',
				'Lebanon,Beirut',
				'67/563572',
				'MALE',
				10000,
				'$',
				'MASTER'


				