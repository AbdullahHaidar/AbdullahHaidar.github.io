
exec AddSupplier  'SP100' ,              
                 'Hadi',
                 'Nasser',
                 'Beirut',   
                 '76170995',
                 'MALE',  
                 'Green House Foods Sarl'

exec AddSupplier  'SP101' ,              
                 'Ali',
                 'Haidar',
                 'Beirut',   
                 '76170995',
                 'MALE',  
                 'United Fisheries Co. Sal'
exec AddSupplier  'SP102' ,              
                 'Hiba',
                 'Hodroj',
                 'Beirut',   
                 '76170995',
                 'FEMALE',  
                 'Personal Bussiness'
exec AddSupplier  'SP103' ,              
                 'Ali',
                 'Assaf',
                 'Beirut',   
                 '76170995',
                 'FEMALE',  
                 'Kamel for Trade'

