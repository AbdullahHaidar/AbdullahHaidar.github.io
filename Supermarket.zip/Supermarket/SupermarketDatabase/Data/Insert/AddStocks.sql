
exec AddStock 'S100','P100',10,2,20
exec AddStock 'S200','P101',10,2,20
exec AddStock 'S300','P102',10,2,20
exec AddStock 'S500','P104',10,2,20
exec AddStock 'S600','P105',10,2,20
exec AddStock 'S700','P106',10,2,20
exec AddStock 'S800','P107',10,2,20
exec AddStock 'S900','P108',10,2,20
exec AddStock 'S1000','P109',10,2,20
exec AddStock 'S1100','P110',10,2,20
exec AddStock 'S1200','P111',10,2,20
