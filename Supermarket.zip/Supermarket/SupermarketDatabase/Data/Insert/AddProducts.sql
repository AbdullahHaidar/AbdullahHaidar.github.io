
--delete  from ORDER_ITEMS
--delete from[ORDER]
--delete  from STOCK
--delete from Product
exec AddProduct  'P100',
				'Nescafe',
				'coffee',
				250,
				'LLP',
				'7-9-2020',
				0.1,
				'111',
				null

exec AddProduct  'P101',
			    'Unica' ,
				'Candy',
				250,
				'LLP',
				'5-11-2019',
				0.1,
				'111111',
				null
exec AddProduct  'P102',
				'Pepsi' ,
				'Beverages',
				1500,
				'LLP',
				'1-10-2021',
				0.1,
				'111000',
				null

exec AddProduct  'P104',
				'Banana' ,
				'Fruit',
				1500,
				'LLP',
				'1-10-2021',
				  0.1,
				  null ,
				'banana.jpg'
exec AddProduct  'P105',
				'Strawberry' ,
				'Fruit',
				3500,
				'LLP',
				'1-10-2021',
				  0.1,
				  null ,
				'straw.jpg'


exec AddProduct  'P106',
				'Grape' ,
				'Fruit',
				3500,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'grape.jpg'
exec AddProduct  'P107',
				'orange' ,
				'Fruit',
				1500,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'orange.jpg'
exec AddProduct  'P108',
				'Tomato' ,
				'Vegetables',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'tomato.jpg'
exec AddProduct  'P109',
				'Lettuce' ,
				'Vegetables',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'lettuc.jpg'
exec AddProduct  'P110',
				'Pear' ,
				'Fruit',
				3000,
				'LLP',
				'1-10-2021',
				  0.1,
				  null ,
				'pear.jpg'
exec AddProduct  'P111',
				'Bread' ,
				'Bread',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'bread2.jpg'

exec AddProduct  'P113',
				'croiss' ,
				'sweets',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'croiss.jpg'
exec AddProduct  'P114',
				'Strawberry Cake' ,
				'sweets',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'cake2.jpg'
exec AddProduct  'P115',
				'Chocolate Cake' ,
				'sweets',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'cake1.jpg'
exec AddProduct  'P116',
				'Chocolate Donut & Sprinkles' ,
				'sweets',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'donut3.jpg'

exec AddProduct  'P117',
				'Knefa' ,
				'sweets',
				2500,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'knefa.jpg'
exec AddProduct  'P118',
				'Chocolate Donut' ,
				'sweets',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'donut1.jpg'
exec AddProduct  'P119',
				'White Frosted Donut' ,
				'sweets',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'donuts.jpg'
exec AddProduct  'P120',
				'Avocado' ,
				'Fruit',
				3000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'avoca.jpg'


exec AddProduct  'P121',
				'Cabbage' ,
				'Vegetable',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'cabb.jpg'


exec AddProduct  'P122',
				'Raddish' ,
				'Vegetable',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'rad.jpg'


exec AddProduct  'P123',
				'Carrots' ,
				'Vegetable',
				1000,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'carr.jpg'
exec AddProduct  'P112',
				'Peach' ,
				'Fruit',
				1500,
				'LLP',
				'1-10-2021',
				  0.0,
				  null ,
				'peach.jpg'







	