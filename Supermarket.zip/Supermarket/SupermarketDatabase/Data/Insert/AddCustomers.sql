
--delete from Customer
exec AddCustomer  'C100',
				'Issa' ,
				'Serhan',
				'5-4-1998',
				'Lebanon,Beirut',
				'67/563572',
				'MALE'

exec AddCustomer  'C101',
				'Hassan' ,
				'Kesserwen',
				'7-3-1998',
				'Lebanon,Beirut',
				'67/594772',
				'MALE'

exec AddCustomer  'C102',
				'Dana' ,
				'Nada',
				'11-9-1998',
				'Lebanon,Beirut',
				'67/438072',
				'FEMALE'