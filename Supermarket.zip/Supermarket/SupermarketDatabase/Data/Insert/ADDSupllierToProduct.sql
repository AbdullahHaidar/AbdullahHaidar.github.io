--delete from SUPPLIER_PRODUCT
use SuperMarket4
exec AddSupplierToProduct 'SP100','P101',200,'LLP'
exec AddSupplierToProduct 'SP101','P101',150,'LLP'
exec AddSupplierToProduct 'SP102','P101',120,'LLP'
exec AddSupplierToProduct 'SP100','P102',200,'LLP'
exec AddSupplierToProduct 'SP100','P104',500,'LLP'
exec AddSupplierToProduct 'SP101','P106',1000,'LLP'
exec AddSupplierToProduct 'SP101','P107',1000,'LLP'
exec AddSupplierToProduct 'SP101','P108',1000,'LLP'
exec AddSupplierToProduct 'SP101','P109',500,'LLP'

