package model;

public interface StatisticsVisitor {
	public void visit(Manager m) ;
	

}
