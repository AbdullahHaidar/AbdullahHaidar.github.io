package model;

public interface StatisticsVisitable {
	public void accept(StatisticsVisitor v);

}
