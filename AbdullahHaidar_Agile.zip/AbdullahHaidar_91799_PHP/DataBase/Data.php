use AgileDB;

update Members set Team=NULL;
delete from Team;
delete from members;
delete  from Project;



insert into members(Name,User,Pass,Mobile,Email,speciality,role) 
values("Administrator","root","root","","","","admin");
insert into team(TITLE) values('Admin');
insert into team(TITLE) values('owner');
insert into members(Team,Name,User,Pass,Mobile,Email,speciality,role,Image) 
values('Admin',"Bassem Haidar","bassem","Aa12345678&","+961 238745","bassem@gmail.com","ProjectManager","coach",'/images/bassem.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Rami Baida","rami","Aa12345678&","+961 238745","rami@gmail.com","ProjectManager",'/images/rami.png');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Ihab Sbeity","ihab","Aa12345678&","+961 238745","ihab@gmail.com","Bussiness",'/images/ihab.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Abed Safedy","abed","Aa12345678&","+961 238745","abed@gmail.com","ProjectManager",'/images/abed.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Kamal Beydoun","kamal","Aa12345678&","+961 238745","kamal@gmail.com","ProjectManager",'/images/kamal.jpg');


insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Abdullah Haidar","abdullah","Aa12345678&","+961 238745","abdullah@gmail.com","Developer",'/images/abd.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Amira Baltajy","amira","Aa12345678&","+961 238745","amira@gmail.com","Developer",'/images/amira.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Ali Rahal","ali","Aa12345678&","+961 238745","ali@gmail.com","Developer",'/images/ali.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Hadi Nasser","hadi","Aa12345678&","+961 238745","hadi@gmail.com","Developer",'/images/hadi.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Nancy Haddad","nancy","Aa12345678&","+961 238745","nancy@gmail.com","Developer",'/images/nancy.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Hassan Badran","hassan","Aa12345678&","+961 238745","hassan@gmail.com","Developer",'/images/hassan.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Yahia Haidar","yahia","Aa12345678&","+961 238745","yahia@gmail.com","Developer",'/images/yahia.jpg');


insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Kamal Haidar","kamal1","Aa12345678&","+961 238745","kamal1@gmail.com","ProjectManager",'/images/kamal1.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Nidal Ali","nidal","Aa12345678&","+961 238745","nidal@gmail.com","ProjectManager",'/images/nidal.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Jad Mrad","jad","Aa12345678&","+961 238745","jad@gmail.com","Developer",'/images/jad.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("George Saab","george","Aa12345678&","+961 238745","george@gmail.com","Developer",'/images/george.jpg');

insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Hussein Hijazy","hussein","Aa12345678&","+961 238745","hussein@gmail.com","Analyst",'/images/hussein.jpg');
insert into members(Name,User,Pass,Mobile,Email,speciality,Image) 
values("Safaa Diab","safaa","Aa12345678&","+961 238745","safaa@gmail.com","Analyst",'/images/safaa.jpg');

update members set Image='/images/t.jpg' where user = 'safaa';