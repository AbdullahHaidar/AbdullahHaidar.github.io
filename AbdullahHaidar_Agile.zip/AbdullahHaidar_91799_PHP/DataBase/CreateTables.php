/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     1/6/2019 1:03:55 AM                          */
/*==============================================================*/


/*==============================================================*/
/* Table: PROJECT                                               */
/*==============================================================*/
drop database agiledb;
create database AgileDB;
use AgileDB;
create table PROJECT
(
   PID                 int  not null Auto_Increment ,
   PROJECTTITLE         varchar(50),
   DESCRIPTION               varchar(200),
   START                datetime,
   END                  datetime,
   DUR                  int,
   DEP                  varchar(40),
   Parent               int null,
   primary key (PID),
   constraint FK_Pro foreign key (Parent)
      references Project (PID) on delete restrict on update restrict
);



/*==============================================================*/
/* Table: MEMBER                                                */
/*==============================================================*/
#drop table Member
create table MEMBERS
(
   MID                int not null Auto_Increment ,
   TEAM                varchar(20),
   NAME                 varchar(40),
   USER                 varchar(30),
   PASS                 varchar(20),
   MOBILE               varchar(30),
   EMAIL                varchar(40),
   speciality            varchar(30),
   IMAGE                  varchar(50),
   ROLE                 varchar(20),
   primary key (MID)
   
);


/*==============================================================*/
/* Table: TEAM                                                  */
/*==============================================================*/

create table TEAM
(
   TITLE                varchar(20) not null,
   COACH                 int,
   scrum                  int,
   PID                  int,
   owner             int,
   primary key (TITLE),
   constraint FK_WORKSON foreign key (PID)
      references PROJECT (PID) on delete restrict on update restrict,
   constraint FK_SCRUMMASTER foreign key (scrum)
      references MEMBERS (MID) on delete restrict on update restrict,
   constraint FK_OWNER foreign key (owner)
      references MEMBERS (MID) on delete restrict on update restrict,
   constraint FK_Co foreign key (COACH)
      references MEMBERS (MID) on delete restrict on update restrict
);
alter table Members
add constraint FK_DEVELOPER foreign key (TEAM)
      references TEAM (TITLE) on delete restrict on update restrict;
/*==============================================================*/
/* Table: QUESTION                                              */
/*==============================================================*/
#drop table QUESTIONNAIRE
create table QUESTIONNAIRE
(
   QRID                  int not null Auto_Increment ,
   COACH                int,
   TITLE                 varchar(50),
   DESCRIPTION           varchar(500),
   NBQUESTIONS               int,
   primary key (QRID),
   constraint FK_ASK1 foreign key (COACH)
      references MEMBERS (MID) on delete restrict on update restrict

);
/*==============================================================*/
/* Table: QUESTION                                              */
/*==============================================================*/
#drop table QUESTION
create table QUESTION
(
   QID                  int not null Auto_Increment ,
   COACH                int,
   TEAM                varchar(20),
   QUESTION             varchar(200),
   QTYPE                 varchar(20),
   QOPTIONS              varchar(500),
   QUESTIONNAIRE               int,
   primary key (QID),
   constraint FK_ASK foreign key (COACH)
      references MEMBERS (MID) on delete restrict on update restrict,
   constraint FK_SEND foreign key (TEAM)
      references TEAM (TITLE) on delete restrict on update restrict,
   constraint FK_Quest2 foreign key (QUESTIONNAIRE)
      references QUESTIONNAIRE (QRID) on delete restrict on update restrict
);

create table Questionnaire_Team
(
QRID   int not null ,
TEAM    varchar(20),
   primary key (QRID, TEAM),
    constraint FK_2 foreign key (QRID)
      references QUESTIONNAIRE (QRID) on delete restrict on update restrict,
   constraint FK_3 foreign key (TEAM)
      references TEAM (TITLE) on delete restrict on update restrict
);

/*==============================================================*/
/* Table: ANSWER                                                */
/*==============================================================*/
#drop table ANSWER
create table ANSWER
(
   QID                  int not null Auto_Increment,
   MID                  int not null,
   ANSWER               int,
   COMMENT              varchar(200),
   primary key (QID, MID),
   constraint FK_ANSWER foreign key (QID)
      references QUESTION (QID) on delete restrict on update restrict,
   constraint FK_ANSWER2 foreign key (MID)
      references MEMBERS (MID) on delete restrict on update restrict
);

/*==============================================================*/
/* Table: NOTIFICATIONS                                                */
/*==============================================================*/
#drop table NOTIFICATIONS
create table NOTIFICATIONS
(
   NID                  int not null Auto_Increment,
   MID                  int not null,
  MESSAGE              varchar(500),
  MREAD                bool,
   primary key (NID),
   constraint FK_ANSWER3 foreign key (MID)
      references MEMBERS (MID) on delete restrict on update restrict
);
drop database agiledb;
drop table ANSWER;
drop table QUESTION;
drop table Questionnaire_Team;
drop table QUESTIONNAIRE;
update members set team =null;
drop table members;
drop table Team;
drop table project;